-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Počítač: 127.0.0.1
-- Vytvořeno: Pon 04. kvě 2020, 17:23
-- Verze serveru: 5.6.21
-- Verze PHP: 5.5.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Databáze: `fm`
--

-- --------------------------------------------------------

--
-- Struktura tabulky `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
`id` int(10) unsigned NOT NULL,
  `email` text NOT NULL,
  `subject` text NOT NULL,
  `message` text NOT NULL,
  `date` varchar(32) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Vypisuji data pro tabulku `messages`
--

INSERT INTO `messages` (`id`, `email`, `subject`, `message`, `date`) VALUES
(1, 'f@gmail.com', 'dd', 'dd', '2020 2 10 17:48:19'),
(2, 'freak@gmail.com', 'Ty woe smrt!', 'SQL Data Types important points\n\n    Not all data types are supported by every relational database vendors. For example, Oracle database doesnâ€™t support DATETIME and MySQL doesnâ€™t support CLOB data type. So while designing database schema and writing sql queries, make sure to check if the data types are supported or not.\n    Data types listed here doesnâ€™t include all the data types, these are the most popularly used data types. Some relational database vendors have their own data types that might be not listed here. For example, Microsoft SQL Server has money and smallmoney data types but since itâ€™s not supported by other popular database vendors, itâ€™s not listed here.\n    Every relational database vendor has itâ€™s own maximum size limit for different data types, you donâ€™t need to remember the limit. Idea is to have the knowledge of what data type to be used in a specific scenario.\n\nLetâ€™s look into different categories of sql data types in detail.\nSQL Numeric Data Types', '2020 2 10 17:53:49'),
(3, 'ss@gmail.com', 'sss', 'Posted byu TheHof12345 14 hours ago R Discord Server  Does anyone know of any discord servers about programming in R specifically  I don t want a generic programming server that has an R bit  I m talking about a total R server  If there isn t one  would anyone be interested in making one helping me make one   The problem I find with sections of other servers  is that no one there knows R  and R is a very niche and unique language ', '2020 2 10 18:07:20'),
(4, 'fffm@gmail.com', 'ff', 'Posted byu TheHof12345 14 hours ago R Discord Server  Does anyone know of any discord  servers abou t p rogramming in R specifically  I don t want a generic programming server that has an R bit  I m talking about a total R server  If there isn t one  would anyone be interested in making one helping me make one   The problem I find with sections of other servers  is that no one there knows R  and R is a very niche and unique language ', '2020 2 10 18:07:54'),
(5, 'jjm@gmail.com', 'jjj', 'Posted byu   TheHof1234  5 14 hours   ago   R Discord Server  Does anyone know of any discord servers about programming in R specifically  I don t want a generic programming server that has an R bit  I m talking about a total R server  If there isn t one  would anyone be interested in making one helping me make one   The problem I find with sections of other servers  is that no one there knows R  and R is a very niche and unique language ', '2020 2 10 18:08:33'),
(6, 'test@gmail.com', 'test', ' INSERT INTO   options   mysql messages                                      email  subject  message  date  VALUES                                       sender          isolate input subject                                            safeSqlQueryVal message           format Sys time      Y  b  d  X         ', '2020 2 10 18:09:23'),
(7, '123@gmail.com', 'weee', '123  INSERT INTO   options   mysql messages                                      email  subject  message  date  VALUES                                       sender          isolate input subject                                            safeSqlQueryVal message           format Sys time      Y  b  d  X         ', '2020 2 10 18:10:01'),
(8, 'ffm@gmail.com', 'fff', 'ff', '2020 2 10 18:12:53'),
(9, 'dd@gmail.com', 'dsdfssd', 'dfdssfdsdfaD W AADC ', '2020 2 10 18:15:03'),
(10, 'D gmail com', 'DDD', 'DD', '2020 2 10 18:16:30'),
(11, 'JJJJ gmail com  ', 'FF', 'FF', '2020 2 10 18:16:41'),
(12, 's@gmail.com', 'ss', '\nAsked 8 years, 8 months ago\nActive 1 year ago\nViewed 122k times\n80\n\nThe following will replace ASCII control characters (shorthand for [x00-x1Fx7F]):\n\nmy_string.replaceAll(\\p{Cntrl}, ?);\n\nThe following will replace all ASCII non-printable characters (shorthand for [p{Graph}x20]), including accented characters:\n\nmy_string.replaceAll([^\\p{Print}], ?);\n\nHowever, neither works for Unicode strings. Does anyone has a good way to remove non-printable characters from a unicode string?\njava string unicode\nshareimprove this question\nedited Jun 14 15 at 23:26\nDavid Foerster\n1,2591010 silver badges2020 bronze badges\nasked Jun 1 11 at 9:26\ndagnelies\n4,43244 gold badges3232 silver badges5050 bronze badges\n\n    2\n    Just as an addendum: the list of Unicode General Categories can be found in UAX #44 â€“ McDowell Jun 1 11 at 10:32\n    Possible duplicate of Fastest way to strip all non-printable characters from a Java String â€“ Stewart Oct 14 16 at 17:34\n    1\n    @Stewart: hi, have you looked at the question/answers besides the title?!? â€“ dagnelies Oct 14 16 at 18:09\n    1\n    @Stewart: that other question covers only the ascii subset of non-printable characters!!! â€“ dagnelies Oct 14 16 at 18:12 \n\nadd a comment\n8 Answers\nactive\noldest\nvotes\n125\n\nmy_string.replaceAll(\\p{C}, ?);\n\nSee more about Unicode regex. java.util.regexPattern/String.replaceAll supports them.\nshareimprove this answer\nedited Jun 15 15 at 0:10\nDavid Foerster\n1,2591010 silver badges2020 bronze badges\nanswered Jun 1 11 at 9:56\nOp De Cirkel\n24.2k66 gold badges3333 silver badges4747 bronze badges\n\n    In java 1.6 at least, there is no support for them. download.oracle.com/javase/6/docs/api/java/util/regex/â€¦ ...I also tried your line out, and besides of missing a backslash, it plainly simply doesnt work. â€“ dagnelies Jun 1 11 at 10:00 \n\nThis works: char c = 0xFFF', '2020 2 10 18:27:51'),
(13, 'sss@gmail.com', 'ss', '    if (!is.null(sender)){      message <- isolate(input$message)      if (message !=//){        # write it...        query <- paste0(/INSERT INTO /,options()$mysql$messages,                                 / (email, subject, message, date) VALUES (//,                                 safeSqlQueryVal(sender), //, //, safeSqlQueryVal(isolate(input$subject)), //, //,                                 safeSqlQueryVal(message), //, //, format(Sys.time(), /%Y %b %d %X/), //)/)', '2020 2 10 18:34:19'),
(14, 'sss@gmail.com', 'sssss', '    if (!is.null(sender)){\n      message <- isolate(input$message)\n      if (message !=//){\n        # write it...\n        query <- paste0(/INSERT INTO /,options()$mysql$messages, \n                                / (email, subject, message, date) VALUES (//, \n                                safeSqlQueryVal(sender), //, //, safeSqlQueryVal(isolate(input$subject)), //, //, \n                                safeSqlQueryVal(message), //, //, format(Sys.time(), /%Y %b %d %X/), //)/)', '2020 2 10 18:35:23'),
(15, 'bbbm@gmail.com', 'bbb', 'bbb', '2020 2 14 1:21:42');

--
-- Klíče pro exportované tabulky
--

--
-- Klíče pro tabulku `messages`
--
ALTER TABLE `messages`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pro tabulky
--

--
-- AUTO_INCREMENT pro tabulku `messages`
--
ALTER TABLE `messages`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
