-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Počítač: 127.0.0.1
-- Vytvořeno: Pon 04. kvě 2020, 17:24
-- Verze serveru: 5.6.21
-- Verze PHP: 5.5.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Databáze: `fm`
--

-- --------------------------------------------------------

--
-- Struktura tabulky `study`
--

CREATE TABLE IF NOT EXISTS `study` (
  `hash` varchar(32) NOT NULL,
  `contributor` text NOT NULL,
  `email` text NOT NULL,
  `affiliation_institute` text NOT NULL,
  `affiliation_country` text NOT NULL,
  `ORCID` text NOT NULL,
  `title` text NOT NULL,
  `authors` text NOT NULL,
  `year` text NOT NULL,
  `journal` text NOT NULL,
  `volume` text NOT NULL,
  `pages` text NOT NULL,
  `doi` text NOT NULL,
  `repository` text NOT NULL,
  `include` text NOT NULL,
  `coauthor` text NOT NULL,
  `email_confirmed` int(11) NOT NULL,
  `submission_finished` int(11) NOT NULL,
  `date` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Vypisuji data pro tabulku `study`
--

INSERT INTO `study` (`hash`, `contributor`, `email`, `affiliation_institute`, `affiliation_country`, `ORCID`, `title`, `authors`, `year`, `journal`, `volume`, `pages`, `doi`, `repository`, `include`, `coauthor`, `email_confirmed`, `submission_finished`, `date`) VALUES
('b2bc39a170bfa6c1978a5ce2682057d9', 'Tomas Vetrovsky', 'kostelecke.uzeniny@seznam.cz', 'MBU', 'Czech Republic', 'ABC1', ' GlobalFungi: Global database of fungal records from high-throughput-sequencing metabarcoding studies', 'Vetrovsky, T. and Baldrian, P.', '2020', 'Scientific Data', '12', '123-132', '10.6666/j.1365-294X.2009.04483.x', 'SRA00666', 'YES', 'YES', 1, 1, '2020 3 31 17:53:46'),
('4e431edcc0245b8c4a594e9210038518', 'Karel', 'dd', 'hhjj', 'hj', 'hh', 'hjh', 'j', 'jj', 'jjj', 'jjj', 'kkk', 'kkk', 'kkk', 'YES', 'YES', 1, 0, '2020 3 31 19:16:56'),
('dd053525be9da7a0d9c39ed003ca6d22', 'RRF', 'kjkj', 'kjkj', 'k', 'jk', 'j', 'kj', 'j', 'klkjkljhkl', 'jkj', 'jkkk', 'kkkkkkkj', 'jkjkk', 'YES', 'YES', 1, 1, '2020 3 31 19:23:21'),
('b068f5e1ac3f97cee78108be667bd6be', 'ghjghjhg', 'jhgghjjh', 'jhgjhggjh', 'gjhgjhjhg', 'ghjgjh', 'hgjjhg', 'hhh', 'hhgghghhghg', 'hghggh', 'hghghgh', 'ghghh', 'ghgh', 'ghgh', 'YES', 'YES', 1, 1, '2020 3 31 20:01:05'),
('ea80ae67bae67248810314210df6e552', 'TTT', 'TTT', 'TTT', 'TTT', 'TTT', 'TTT', 'TTT', '2020', 'TTT', 'TTT', 'TTT', 'TTT', 'TTT', 'YES', 'YES', 1, 1, '2020 4 01 13:15:11'),
('0e6ee666860be41bd731f71e8992c57b', 'erse', 'esseff', 'seffse', 'seff', 'sefef', 'sefsfe', 'sedfsd', 'fsdf', 'sdfsfd', 'sdffsd', 'klkklk', 'jjj', 'nnn', 'YES', 'YES', 1, 1, '2020 4 08 19:59:28');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
