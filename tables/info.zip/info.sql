-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Počítač: 127.0.0.1
-- Vytvořeno: Pon 04. kvě 2020, 17:23
-- Verze serveru: 5.6.21
-- Verze PHP: 5.5.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Databáze: `fm`
--

-- --------------------------------------------------------

--
-- Struktura tabulky `info`
--

CREATE TABLE IF NOT EXISTS `info` (
`id` int(10) unsigned NOT NULL,
  `name` text NOT NULL,
  `version` text NOT NULL,
  `release` text NOT NULL,
  `unite_version` text NOT NULL,
  `its1_raw_count` int(11) NOT NULL,
  `its2_raw_count` int(11) NOT NULL,
  `info` text NOT NULL,
  `citation` text NOT NULL,
  `date` varchar(32) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Vypisuji data pro tabulku `info`
--

INSERT INTO `info` (`id`, `name`, `version`, `release`, `unite_version`, `its1_raw_count`, `its2_raw_count`, `info`, `citation`, `date`) VALUES
(1, 'GlobalFungi', 'v0.9.6', '1.0', '8.1(2.2.2019)', 416291533, 231278756, 'Beta version', 'V?trovský, T. et al. (2020) GlobalFungi: Global database of fungal records from high-throughput-sequencing metabarcoding studies. Scientific Data', '27.3.2020');

--
-- Klíče pro exportované tabulky
--

--
-- Klíče pro tabulku `info`
--
ALTER TABLE `info`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pro tabulky
--

--
-- AUTO_INCREMENT pro tabulku `info`
--
ALTER TABLE `info`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
