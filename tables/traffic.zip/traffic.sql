-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Počítač: 127.0.0.1
-- Vytvořeno: Pon 04. kvě 2020, 17:25
-- Verze serveru: 5.6.21
-- Verze PHP: 5.5.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Databáze: `fm`
--

-- --------------------------------------------------------

--
-- Struktura tabulky `traffic`
--

CREATE TABLE IF NOT EXISTS `traffic` (
`id` int(10) unsigned NOT NULL,
  `session` int(11) NOT NULL,
  `category` varchar(32) DEFAULT NULL,
  `value` varchar(64) DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=110 DEFAULT CHARSET=latin1;

--
-- Vypisuji data pro tabulku `traffic`
--

INSERT INTO `traffic` (`id`, `session`, `category`, `value`, `date`) VALUES
(1, 62, 'species', 'Absidia glauca', '2020-02-20 15:25:44'),
(2, 63, 'genus', 'Neofusicoccum', '2020-02-20 21:44:39'),
(3, 63, 'genus', 'Populocrescentia', '2020-02-20 21:44:44'),
(4, 63, 'species', 'Cortinarius mucosus', '2020-02-20 21:44:50'),
(5, 64, 'species', 'Serpula himantioides', '2020-02-20 21:46:09'),
(6, 64, 'species', 'Absidia glauca', '2020-02-20 21:46:26'),
(7, 65, 'sequence', '1', '2020-02-20 22:09:45'),
(8, 66, 'genus', 'Absidia', '2020-02-21 13:47:15'),
(9, 67, 'genus', 'Zignoella', '2020-02-21 13:51:57'),
(10, 68, 'study', 'van_der_Wal_2017_2D0D', '2020-02-21 13:52:09'),
(11, 69, 'genus', 'Kazachstania', '2020-02-21 20:39:57'),
(12, 70, 'genus', 'Absidia', '2020-02-25 09:53:59'),
(13, 71, 'genus', 'Absidia', '2020-02-25 10:35:17'),
(14, 72, 'genus', 'Absidia', '2020-02-25 10:36:49'),
(15, 73, 'genus', 'Absidia', '2020-02-25 10:40:55'),
(16, 74, 'genus', 'Absidia', '2020-02-25 10:52:46'),
(17, 75, 'genus', 'Absidia', '2020-02-25 10:54:36'),
(18, 75, 'genus', 'Absidia', '2020-02-25 11:07:45'),
(19, 76, 'sequence', '1', '2020-02-25 11:16:28'),
(20, 76, 'sequence', '1', '2020-02-25 11:17:12'),
(21, 76, 'sequence', '1', '2020-02-25 11:18:01'),
(22, 76, 'sequence', '1', '2020-02-25 11:18:23'),
(23, 77, 'SH', 'SH1515425.08FU', '2020-02-25 11:18:51'),
(24, 78, 'genus', 'Absidia', '2020-02-26 07:36:13'),
(25, 79, 'genus', 'Absidia', '2020-02-26 22:34:19'),
(26, 80, 'species', 'Absidia glauca', '2020-02-26 22:35:27'),
(27, 81, 'genus', 'Absidia', '2020-02-26 22:37:35'),
(28, 82, 'genus', 'Absidia', '2020-02-26 22:41:44'),
(29, 82, 'genus', 'Acremonium', '2020-02-26 22:42:03'),
(30, 82, 'genus', 'Acrostalagmus', '2020-02-26 22:42:43'),
(31, 83, 'genus', 'Absidia', '2020-02-27 17:26:14'),
(32, 84, 'genus', 'Absidia', '2020-02-27 17:27:50'),
(33, 85, 'genus', 'Leucoagaricus', '2020-02-27 17:30:27'),
(34, 86, 'genus', 'Absidia', '2020-02-27 17:32:07'),
(35, 87, 'genus', 'Absidia', '2020-02-27 17:36:21'),
(36, 87, 'species', 'Acremonium acutatum', '2020-02-27 17:37:32'),
(37, 88, 'genus', 'Absidia', '2020-02-27 17:43:59'),
(38, 89, 'genus', 'Absidia', '2020-02-27 17:45:40'),
(39, 90, 'genus', 'Absidia', '2020-02-27 17:53:00'),
(40, 91, 'genus', 'Absidia', '2020-02-27 17:54:25'),
(41, 92, 'genus', 'Zignoella', '2020-02-27 17:55:28'),
(42, 93, 'genus', 'Absidia', '2020-02-27 17:59:27'),
(43, 94, 'genus', 'Ganoderma', '2020-02-27 18:02:29'),
(44, 95, 'genus', 'Absidia', '2020-02-27 18:08:35'),
(45, 96, 'genus', 'Pilidium', '2020-02-27 18:15:03'),
(46, 97, 'species', 'Absidia glauca', '2020-02-27 18:16:00'),
(47, 98, 'genus', 'Absidia', '2020-02-27 18:17:44'),
(48, 99, 'genus', 'Acremonium', '2020-02-27 18:21:41'),
(49, 100, 'species', 'Descolea maculata', '2020-02-27 18:31:19'),
(50, 101, 'genus', 'Absidia', '2020-02-27 18:33:09'),
(51, 102, 'genus', 'Absidia', '2020-02-27 18:34:11'),
(52, 103, 'species', 'Macrolepiota procera', '2020-03-02 10:36:44'),
(53, 103, 'genus', 'Cortinarius', '2020-03-02 10:37:22'),
(54, 104, 'genus', 'Absidia', '2020-03-02 15:03:03'),
(55, 104, 'study', 'DelgadoBaquerizo_2017_BB88', '2020-03-02 15:07:12'),
(56, 105, 'genus', 'Absidia', '2020-03-02 15:51:34'),
(57, 105, 'study', 'DelgadoBaquerizo_2017_BB88', '2020-03-02 15:51:47'),
(58, 106, 'study', 'DelgadoBaquerizo_2017_BB88', '2020-03-02 15:52:42'),
(59, 107, 'study', 'Truong_2019_add', '2020-03-02 16:11:36'),
(60, 108, 'study', 'Bissett_AAAA_2016', '2020-03-02 16:14:29'),
(61, 109, 'study', 'Truong_2019_add', '2020-03-02 16:14:54'),
(62, 109, 'genus', 'Absidia', '2020-03-02 16:15:09'),
(63, 109, 'genus', 'Hygrocybe', '2020-03-02 16:24:49'),
(64, 109, 'genus', 'Hygrocybe', '2020-03-02 16:25:04'),
(65, 110, 'genus', 'Absidia', '2020-03-02 16:30:13'),
(66, 110, 'genus', 'Penicillium', '2020-03-02 16:30:31'),
(67, 111, 'genus', 'Absidia', '2020-03-02 16:32:36'),
(68, 111, 'species', 'Absidia glauca', '2020-03-02 16:33:00'),
(69, 111, 'genus', 'Acremonium', '2020-03-02 16:33:11'),
(70, 112, 'genus', 'Absidia', '2020-03-02 16:40:36'),
(71, 113, 'genus', 'Absidia', '2020-03-02 16:42:16'),
(72, 114, 'genus', 'Acicuseptoria', '2020-03-02 16:43:33'),
(73, 114, 'genus', 'Penicillium', '2020-03-02 16:43:55'),
(74, 115, 'genus', 'Absidia', '2020-03-02 16:44:49'),
(75, 115, 'genus', 'Penicillium', '2020-03-02 16:45:02'),
(76, 115, 'genus', 'Peniophorella', '2020-03-02 16:45:21'),
(77, 116, 'genus', 'Absidia', '2020-03-02 16:47:07'),
(78, 117, 'genus', 'Absidia', '2020-03-02 16:48:58'),
(79, 118, 'genus', 'Absidia', '2020-03-02 16:49:46'),
(80, 118, 'genus', 'Penicillium', '2020-03-02 16:49:59'),
(81, 119, 'genus', 'Absidia', '2020-03-02 16:51:20'),
(82, 119, 'genus', 'Acremonium', '2020-03-02 16:51:28'),
(83, 119, 'genus', 'Acrostalagmus', '2020-03-02 16:51:37'),
(84, 120, 'genus', 'Absidia', '2020-03-02 16:57:05'),
(85, 120, 'genus', 'Penicillium', '2020-03-02 16:57:19'),
(86, 120, 'genus', 'Peniophorella', '2020-03-02 16:57:41'),
(87, 121, 'genus', 'Acremoniopsis', '2020-03-02 17:01:03'),
(88, 122, 'genus', 'Acrophialophora', '2020-03-02 17:02:01'),
(89, 123, 'genus', 'Acicuseptoria', '2020-03-02 17:03:21'),
(90, 123, 'genus', 'Graphium', '2020-03-02 17:03:41'),
(91, 124, 'genus', 'Absidia', '2020-03-02 17:05:30'),
(92, 124, 'genus', 'Pectenia', '2020-03-02 17:05:47'),
(93, 124, 'genus', 'Penicillium', '2020-03-02 17:06:12'),
(94, 124, 'genus', 'Peltigera', '2020-03-02 17:06:28'),
(95, 125, 'genus', 'Acremoniopsis', '2020-03-02 17:11:10'),
(96, 125, 'genus', 'Acremoniopsis', '2020-03-02 17:11:25'),
(97, 126, 'genus', 'Absidia', '2020-03-02 17:11:37'),
(98, 126, 'genus', 'Penicillium', '2020-03-02 17:11:55'),
(99, 127, 'study', 'Stursova_2016_D385', '2020-03-04 21:54:04'),
(100, 127, 'genus', 'Acremoniopsis', '2020-03-04 21:54:33'),
(101, 127, 'genus', 'Russula', '2020-03-04 21:55:09'),
(102, 128, 'genus', 'Dichotomopilus', '2020-03-11 14:38:52'),
(103, 129, 'genus', 'Acremonium', '2020-03-11 14:44:11'),
(104, 130, 'genus', 'Absidia', '2020-03-11 14:51:30'),
(105, 131, 'genus', 'Orbilia', '2020-03-11 16:29:19'),
(106, 132, 'genus', 'Absidia', '2020-03-19 15:47:45'),
(107, 132, 'study', 'Bissett_AAAA_2016', '2020-03-19 15:47:54'),
(108, 134, 'species', 'Acremoniopsis suttonii', '2020-03-31 17:25:43'),
(109, 135, 'species', 'Absidia glauca', '2020-04-15 12:02:46');

--
-- Klíče pro exportované tabulky
--

--
-- Klíče pro tabulku `traffic`
--
ALTER TABLE `traffic`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pro tabulky
--

--
-- AUTO_INCREMENT pro tabulku `traffic`
--
ALTER TABLE `traffic`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=110;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
